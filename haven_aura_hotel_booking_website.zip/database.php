<?php
session_start();
$host='localhost'; $user='root'; $pass=''; $db='hotel_booking_db';
$conn=new mysqli($host,$user,$pass);
if($conn->connect_error) die('Database connection failed: '.htmlspecialchars($conn->connect_error));
$conn->query("CREATE DATABASE IF NOT EXISTS `$db`"); $conn->select_db($db); $conn->set_charset('utf8mb4');
$schema=[
"CREATE TABLE IF NOT EXISTS users(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARCHAR(150) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL,phone VARCHAR(30),address VARCHAR(255),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",
"CREATE TABLE IF NOT EXISTS admins(id INT AUTO_INCREMENT PRIMARY KEY,username VARCHAR(50) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL)",
"CREATE TABLE IF NOT EXISTS rooms(id INT AUTO_INCREMENT PRIMARY KEY,type VARCHAR(50) UNIQUE NOT NULL,description TEXT,price DECIMAL(10,2) NOT NULL,quantity INT NOT NULL DEFAULT 1,amenities TEXT,image VARCHAR(255))",
"CREATE TABLE IF NOT EXISTS bookings(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,room_id INT NOT NULL,check_in DATE NOT NULL,check_out DATE NOT NULL,guests INT NOT NULL DEFAULT 1,total DECIMAL(10,2) NOT NULL,payment_status ENUM('Pending','Paid','Refunded') DEFAULT 'Pending',booking_status ENUM('Confirmed','Cancelled','Completed') DEFAULT 'Confirmed',payment_ref VARCHAR(100),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(room_id) REFERENCES rooms(id) ON DELETE RESTRICT)",
"CREATE TABLE IF NOT EXISTS reviews(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,room_id INT NOT NULL,rating TINYINT NOT NULL,comment TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY one_review(user_id,room_id),FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(room_id) REFERENCES rooms(id) ON DELETE CASCADE)",
"CREATE TABLE IF NOT EXISTS pages(id INT AUTO_INCREMENT PRIMARY KEY,slug VARCHAR(60) UNIQUE NOT NULL,title VARCHAR(150) NOT NULL,content LONGTEXT NOT NULL,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)",
"CREATE TABLE IF NOT EXISTS messages(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100),email VARCHAR(150),message TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)"
]; foreach($schema as $sql) $conn->query($sql);
$check=$conn->query("SELECT id FROM admins LIMIT 1"); if($check&&$check->num_rows===0){$h=password_hash('admin123',PASSWORD_DEFAULT);$s=$conn->prepare('INSERT INTO admins(username,password) VALUES(?,?)');$u='admin';$s->bind_param('ss',$u,$h);$s->execute();}
$roomCount=(int)($conn->query('SELECT COUNT(*) n FROM rooms')->fetch_assoc()['n']??0); if($roomCount===0){$rooms=[
['Standard','Comfortable room with a queen bed, work desk and city views.',89,8,'Queen bed, Wi-Fi, Smart TV, Breakfast'],['Deluxe','Spacious room with upgraded interiors and a relaxing seating area.',129,6,'King bed, Wi-Fi, Smart TV, Breakfast, Mini fridge'],['Executive','Elegant business-ready room with lounge seating and premium amenities.',179,4,'King bed, Work desk, Wi-Fi, Breakfast, Coffee bar'],['Presidential Suite','Signature suite with separate living space, balcony and luxury bath.',299,2,'King bed, Living room, Balcony, Wi-Fi, Breakfast, Bathtub']]; $s=$conn->prepare('INSERT INTO rooms(type,description,price,quantity,amenities,image) VALUES(?,?,?,?,?,?)'); foreach($rooms as $r){$img='assets/room-'.($roomCount+1).'.svg';$s->bind_param('ssdiss',$r[0],$r[1],$r[2],$r[3],$r[4],$img);$s->execute();$roomCount++;}}
$pageData=[
['about','About HavenAura','HavenAura is a modern city hotel designed for effortless stays, combining calm interiors, thoughtful service and convenient access to local attractions.'],
['contact','Contact Us','24/7 Guest Desk: +91 90000 12345<br>Email: stay@havenaura.example<br>Address: 24 Marina View Road, Chennai'],
['faq','Customer Service Q&A','<b>What time is check-in?</b><br>Check-in starts at 2:00 PM.<br><br><b>What time is check-out?</b><br>Check-out is by 11:00 AM.<br><br><b>Can I cancel?</b><br>Guests can modify or cancel up to 3 days before arrival.'],
['travel','Local Travel & Shipping Guide','Explore Marina Beach, Kapaleeshwarar Temple, Fort St. George and local food streets. Airport transfers and luggage/shipping assistance can be arranged through the front desk.'],
['privacy','Privacy Policy','We use account and booking information only to provide hotel services, process reservations, support guests and improve the website. We do not sell personal information.']]; foreach($pageData as $p){$s=$conn->prepare('INSERT IGNORE INTO pages(slug,title,content) VALUES(?,?,?)');$s->bind_param('sss',$p[0],$p[1],$p[2]);$s->execute();}
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function require_login(){if(empty($_SESSION['user_id'])){header('Location: login.php');exit;}}
function require_admin(){if(empty($_SESSION['admin_id'])){header('Location: login.php');exit;}}
function csrf(){if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(16));return $_SESSION['csrf'];}
function check_csrf(){if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')){http_response_code(419);exit('Invalid request token.');}}
function available_rooms($conn,$room_id,$in,$out,$exclude=0){$sql="SELECT quantity-(SELECT COUNT(*) FROM bookings b WHERE b.room_id=r.id AND b.booking_status='Confirmed' AND b.check_in < ? AND b.check_out > ? AND b.id<>?) available FROM rooms r WHERE r.id=?";$s=$conn->prepare($sql);$s->bind_param('ssii',$out,$in,$exclude,$room_id);$s->execute();return max(0,(int)($s->get_result()->fetch_assoc()['available']??0));}
function can_change_booking($date){return (strtotime($date)-strtotime(date('Y-m-d'))) >= 3*86400;}
?>