# HavenAura Hotel Booking Website

A PHP/MySQL responsive hotel room booking system with four room types, date availability, user profiles, booking history, 3-day modification/cancellation rule, payment status, reviews, and an admin CMS.

Default admin: admin / admin123. Change it before deployment.

Open index.php through a PHP/MySQL server. database.php creates the database and tables automatically.

Payment is implemented as a secure demo flow that records a paid transaction reference; connect your preferred gateway (Razorpay/Stripe/etc.) for production card processing. Email confirmation can be wired to SMTP/mail service.
