# RouteWave – Online Bus Ticket Booking System

A responsive PHP/MySQL academic project converted into a complete online bus ticket booking website.

## Main modules
- User registration/login
- Forgot password and change password
- Route/date/time bus search
- Four bus categories: Volvo, Sleeper Coach, Coach, AC Seater
- Bus schedules, operators, fares and seat availability
- Visual seat selection with unavailable seats disabled
- Passenger details and demo secure payment flow
- Booking reference and confirmation page
- Booking history and ticket cancellation
- Passenger comments and ratings for buses
- News/updates section
- Admin dashboard
- Bus category management
- Bus/schedule/price/quantity/availability management
- Booking modification/cancellation
- Registered user management
- Comment moderation
- News management
- Static page CMS
- Booking/revenue report generation
- Responsive mobile-first design

## Local setup
1. Extract the ZIP into your PHP server directory (XAMPP htdocs, WAMP www, etc.).
2. Make sure Apache and MySQL are running.
3. Open `index.php` in the browser.
4. `database.php` automatically creates `bus_ticket_booking_db`, tables and sample data when the MySQL user has database-creation permission.
5. Default admin: `admin` / `admin123`.

## Demo payment
The checkout is an academic/demo payment form. No card information is sent to a real processor. For production, replace the payment handler with Razorpay, Stripe, or another gateway.

## Email confirmation
The booking confirmation attempts to use PHP `mail()` after payment. Configure a mail transport on the server for actual email delivery.
