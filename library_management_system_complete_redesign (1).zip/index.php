<?php require 'database.php'; ?>
<!doctype html>
<html lang="en">
<head><link rel="icon" href="favicon.svg" type="image/svg+xml">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Horizon Library | Discover Knowledge</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>
  <a class="brand" href="index.php">Horizon Library</a>
  <nav>
    <a href="index.php">Home</a>
    <a href="books.php">Catalog</a>
    <a href="contact.php">Contact</a>
    <?php if(!empty($_SESSION['user_id'])): ?>
      <a href="my_books.php">My Books</a><a href="logout.php">Logout</a>
    <?php else: ?>
      <a href="login.php">Student Login</a><a href="register.php">Register</a>
    <?php endif; ?>
    <a href="admin/login.php">Admin</a>
  </nav>
</header>

<main class="container">
  <section class="hero">
    <div>
      <h2>Read · Learn · Grow</h2>
      <h1>Your digital doorway to the campus library.</h1>
      <p>Discover books, check availability, request titles and keep your reading history organized in one calm, modern space.</p>
      <a class="btn gold" href="books.php">Explore the catalog</a>
      <a class="btn secondary" href="register.php">Create student account</a>
    </div>
  </section>

  <section class="grid">
    <article class="card">
      <h3>01 · Explore</h3>
      <p>Find books by title, author or category and open a full details page before requesting a copy.</p>
    </article>
    <article class="card">
      <h3>02 · Request</h3>
      <p>Send a borrowing request in seconds and follow its approval, issue and return status from your account.</p>
    </article>
    <article class="card">
      <h3>03 · Manage</h3>
      <p>Library administrators can maintain the catalog, students, requests and returns from one dashboard.</p>
    </article>
  </section>
</main>

<footer>Horizon Library Management System · Built for a better campus reading experience</footer>
<script src="script.js"></script>
</body>
</html>