document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-confirm]").forEach(el => {
    el.addEventListener("click", e => {
      if (!confirm(el.dataset.confirm)) e.preventDefault();
    });
  });

  document.querySelectorAll("form").forEach(form => {
    form.addEventListener("submit", () => {
      const button = form.querySelector("button[type='submit'], button:not([type])");
      if (button && !button.dataset.keepText) {
        button.dataset.keepText = "1";
        button.dataset.originalText = button.textContent;
        button.textContent = "Please wait…";
        button.disabled = true;
      }
    });
  });

  const search = document.querySelector('input[name="q"]');
  if (search) {
    search.setAttribute("aria-label", "Search the book catalog");
  }
});
